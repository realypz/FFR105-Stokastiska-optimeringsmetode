%%  test the best chromosome
clc; clear; close all;

%% load the best chromosome
BestChromosome;

%%
string = PrintGx(bestChromosome);
syms x1;
expression = str2sym(string);
simplifiedExpression = simplify(expression)

%% Compute the yEstimate, and RMS error.
functionData = LoadFunctionData;
x = functionData(:,1);
yTrue = functionData(:,2);

yEstimate = yTrue;

for i = 1:length(x)
    yEstimate(i) =  FunctionFromChromosome(x(i), bestChromosome);
%     yEstimate(i) =  BestFunction(x(i));
end

rmsError = rms(yEstimate - yTrue);

%% Print and display
disp(["rms error of the best fitting is "+ num2str(rmsError)]);
plot(x, yEstimate);
hold all;
plot(x, yTrue);
legend("true curve", "estimated curve");



%% Hardcode the function simplified
function y = BestFunction(x1)
    y = (2048*x1^5 + 2176*x1^4 - 416*x1^3 + 104*x1^2 + 1418*x1 + 627)/(2048*x1^6 + 3968*x1^5 + 1184*x1^4 - 2056*x1^3 - 426*x1^2 + 1419*x1 + 671);
end


function str = PrintGx(bestChromosome)
    sectionLength = 4;
    nSection = length(bestChromosome)/sectionLength;

    registers = ["x1", "0", "0", "1", "2", "4", "8", "16"];
    operators = ["+", "-", "*", "/"];
        
    for i = 1:nSection
        chromosomeSection = bestChromosome(1 + (i - 1) * sectionLength: i * sectionLength);
        operatorIndex = chromosomeSection(1);
        destinationRegisterIndex = chromosomeSection(2);
        operand1Index = chromosomeSection(3);
        operand2Index = chromosomeSection(4);
        registers(destinationRegisterIndex) = "(" + registers(operand1Index) + operators(operatorIndex) + registers(operand2Index) + ")";
    end
    
    str = registers(1);
end

