function  fitness = EvaluateIndividual(chromosome, functionData)
%% compute the rms error of a chromosome.
    dataLength = length(functionData);
    yEstimate = zeros(dataLength, 1);
    x = functionData(:,1);
    yTrue = functionData(:,2);
    
    for i = 1:dataLength
        yEstimate(i) = FunctionFromChromosome(x(i), chromosome);
    end
    
    errorVector = yEstimate - yTrue;
    
    chromosomeLength = size(chromosome, 2);
    
    lengthThreshold = 200;
    
    if (chromosomeLength >= lengthThreshold)
        penaltyFactor = exp(-0.05 *(chromosomeLength - lengthThreshold));
    else
        penaltyFactor = 1;
    end
    
    fitness = 1 / rms(errorVector) * penaltyFactor;
end