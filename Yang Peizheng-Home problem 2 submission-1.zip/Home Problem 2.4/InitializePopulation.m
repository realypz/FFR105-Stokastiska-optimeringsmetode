function populationStruct = InitializePopulation(populationSize, unitChromosomeRange, nOperationRange)
    % unitChromosome is four genes that determines an operation.
    % nOperationRange determines the min and max # of operations of the
    % chromosome.
       
    minNumberOfOperation = min(nOperationRange);
    maxNumberOfOperation = max(nOperationRange);  
    %%randi([1, ����], 1)
    
    for i = 1:populationSize
        randomChromosomeLength = 4 * randi([minNumberOfOperation, maxNumberOfOperation], 1);
        thisChromosome = zeros(1, randomChromosomeLength);
        
        for j = 1:randomChromosomeLength
            for k = 1:4:randomChromosomeLength
                thisChromosome(k) = randi([1, unitChromosomeRange(1)], 1);
            end
            
            for k = 2:4:randomChromosomeLength
                thisChromosome(k) = randi([1, unitChromosomeRange(2)], 1);
            end
            
            for k = 3:4:randomChromosomeLength
                thisChromosome(k) = randi([1, unitChromosomeRange(3)], 1);
            end 
            
            for k = 4:4:randomChromosomeLength
                thisChromosome(k) = randi([1, unitChromosomeRange(4)], 1);
            end     
        end
        populationStruct.index(i).values = thisChromosome;
    end
end