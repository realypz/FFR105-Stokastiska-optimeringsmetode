function newChromosomePair = TwoPointCrossover(chromosome1, chromosome2)
    nSectionChromosome1 = length(chromosome1)/4;
    nSectionChromosome2 = length(chromosome2)/4;
    crossoverPointChromosome1 = 4 * randperm(nSectionChromosome1 - 1, 2);   % randomly generate the two numbers as split positons, let's say 45, 23
    crossoverPointChromosome1 = sort(crossoverPointChromosome1);    % Make sure that the order is Ascending! then it becomes 23, 45.
%     disp("the first chromosome's crossover point")
%     disp(crossoverPointChromosome1);
    
    crossoverPointChromosome2 = 4 * randperm(nSectionChromosome2 - 1, 2);
    crossoverPointChromosome2 = sort(crossoverPointChromosome2);  
%     disp("the second chromosome's crossover point")
%     disp(crossoverPointChromosome2);
    
    % split chromosome1 and chromosome2.
    chromosome1Split.part1 = chromosome1(1 : crossoverPointChromosome1(1));
    chromosome1Split.part2 = chromosome1(crossoverPointChromosome1(1) + 1 : crossoverPointChromosome1(2));
    chromosome1Split.part3 = chromosome1(crossoverPointChromosome1(2) + 1 : end);
    
    chromosome2Split.part1 = chromosome2(1 : crossoverPointChromosome2(1));
    chromosome2Split.part2 = chromosome2(crossoverPointChromosome2(1) + 1 : crossoverPointChromosome2(2));
    chromosome2Split.part3 = chromosome2(crossoverPointChromosome2(2) + 1 : end);

    % Crossover the two chromosomes.
    newChromosomePair.first = [chromosome1Split.part1, chromosome2Split.part2, chromosome1Split.part3];
    newChromosomePair.second = [chromosome2Split.part1, chromosome1Split.part2, chromosome2Split.part3];
end