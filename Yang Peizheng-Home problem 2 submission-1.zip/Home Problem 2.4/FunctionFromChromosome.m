function yEstimate = FunctionFromChromosome(x, chromosome)
    %% Register set
    variableRegister = [x, 0, 0];
    constantRegister = [1, 2, 4, 8, 16];
    
    registerSet = [variableRegister, constantRegister];
    

    
    chromosomeLength = length(chromosome);
    nOperation = chromosomeLength/4;
    
    cMax = 1e8; % return cMax when b = 0 occurs in a/b.
    
    %% Decode the chromosome for one pair of functionData (input, output)
    
    for iOperation = 1:nOperation
        chromosomeSection = chromosome(1 + 4 * (iOperation - 1) : 4 * iOperation);
        
        % registers
        operatorIndex = chromosomeSection(1);
        destinationRegisterIndex = chromosomeSection(2);
        operand1Index = chromosomeSection(3);
        operand2Index = chromosomeSection(4);
        
        if operatorIndex == 1 % +
            registerSet(destinationRegisterIndex) = registerSet(operand1Index) + registerSet(operand2Index);
        elseif operatorIndex == 2 % -
            registerSet(destinationRegisterIndex) = registerSet(operand1Index) - registerSet(operand2Index);
        elseif operatorIndex == 3 % *
            registerSet(destinationRegisterIndex) = registerSet(operand1Index) * registerSet(operand2Index);
        elseif operatorIndex == 4 % /
            if (registerSet(operand2Index) ~= 0)
                registerSet(destinationRegisterIndex) = registerSet(operand1Index) / registerSet(operand2Index);
            else
                registerSet(destinationRegisterIndex) = cMax;
            end
        end   
    end
    
    yEstimate = registerSet(1);
end

