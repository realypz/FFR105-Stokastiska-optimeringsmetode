function modifiedPopulation = InsertBestIndividual(population, bestIndividual, nCopies)  
    modifiedPopulation = population;   
    for i = 1:nCopies
        modifiedPopulation.index(i).values = bestIndividual;
    end  
end