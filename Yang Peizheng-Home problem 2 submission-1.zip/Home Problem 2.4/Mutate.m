function mutatedChromosome = Mutate(chromosome, unitChromosomeRange, active) %% �������Ҫ�ģ�

    
    chromsomeLength = size(chromosome, 2);
    sectionLength = size(unitChromosomeRange, 2); % - 4, Four genes determines an operation.
    
    % Mutation probability is set as the 1/chromsomeLength
    if active == 0
        mutationProbability = 1 / chromsomeLength;
    else
        mutationProbability = 0.5;
    end

    
    mutatedChromosome = chromosome;

    
    for iSection = 1:sectionLength %1:4
        for j = iSection:sectionLength:chromsomeLength
           r = rand;
           if (r <= mutationProbability)
               while (mutatedChromosome(j) == chromosome(j))
                   mutatedChromosome(j) = randperm(unitChromosomeRange(iSection), 1);  
               end
           end
        end
    end
end