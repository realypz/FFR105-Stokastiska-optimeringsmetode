%% LGP 2.4
clear; clc; close all;

%% Load function data
functionData = LoadFunctionData;
dataLength = length(functionData);

%% Params
nVariableReg = 3;
nConstantReg = 5;

nGeneration = 1e6;
populationSize = 150;

nCopies = 3;

tournamentSelectionParameter = 0.75;
tournamentSize = 2;
crossoverProbability = 0.2;
nOperationRange = [8, 20];

unitChromosomeRange = [4, nVariableReg, nVariableReg + nConstantReg, nVariableReg + nConstantReg];

population = InitializePopulation(populationSize, unitChromosomeRange, nOperationRange);
fitnessVector = zeros(populationSize, 1);



x = functionData(:, 1);
yTrue = functionData(:, 2);

bestFitnessValue = -Inf;

lastRMSValue = Inf;


activate = 0;
for iGeneration = 1:nGeneration
%% Find the best chromosome
    activate = 0;
    for iChromosome = 1:populationSize
        chromosome = population.index(iChromosome).values;
        thisFitness = EvaluateIndividual(chromosome, functionData);
        fitnessVector(iChromosome) = thisFitness;

        if(thisFitness > bestFitnessValue)
            bestFitnessValue = thisFitness;
            bestChromosome = chromosome;
        end
    end
    
    if (mod(iGeneration, 10) == 0 )
        disp(["iteration = " + num2str(iGeneration)]);
        yEstimate = zeros(dataLength, 1);
        for i = 1:dataLength
            yEstimate(i) = FunctionFromChromosome(x(i), bestChromosome);
        end
        
        rmsValue = rms(yTrue - yEstimate);
        disp(["RMS is ", num2str(rmsValue)]);
        
        if rmsValue < lastRMSValue
            lastRMSValue = rmsValue;
            lastIteration = iGeneration;
        end
        
        if iGeneration - lastIteration > 500
            activate = 1;
            lastIteration = iGeneration;
        end
    end
   
    % Form the next generation.
    tempPopulation = population;

    for i = 1:2:populationSize

        % Select two individuals i1 and i2 from the evaluated population.
        i1 = TournamentSelect(fitnessVector, tournamentSelectionParameter, tournamentSize);
        i2 = TournamentSelect(fitnessVector, tournamentSelectionParameter, tournamentSize);
        chromosome1 = population.index(i1).values;
        chromosome2 = population.index(i2).values;

        % Generate two offspring chromosomes by crossing, with probability pc,
        % the two chromosomes ci1 and ci2 of the two parents. With probability
        % 1-c, copy the parent chromosomes without modification.

        r = rand;
        if (r < crossoverProbability)
            newChromosomePair = TwoPointCrossover(chromosome1, chromosome2);             
            tempPopulation.index(i).values = Mutate(newChromosomePair.first, unitChromosomeRange, activate);
            tempPopulation.index(i+1).values = Mutate(newChromosomePair.second, unitChromosomeRange, activate); 
        else
            tempPopulation.index(i).values = Mutate(chromosome1, unitChromosomeRange, activate);
            tempPopulation.index(i+1).values = Mutate(chromosome2, unitChromosomeRange, activate);
        end
    end

    % Elitism
    modifiedPopulation = InsertBestIndividual(tempPopulation, bestChromosome, nCopies);

    population = modifiedPopulation; % Update the population of this generation.
end

save('bestChromosome.mat','bestChromosome');

%% compute yEstimate from the best chromosome.
yEstimate = zeros(dataLength, 1);
x = functionData(:, 1);
yTrue = functionData(:, 2);

for i = 1:dataLength
    yEstimate(i) = FunctionFromChromosome(x(i), bestChromosome);
end

plot(x, yEstimate, 'b');
title("y Estimate")
hold on;
plot(x, yTrue, 'r');
title("y True")

disp(rms(yTrue - yEstimate));
