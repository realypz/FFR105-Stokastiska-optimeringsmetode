function pheromoneLevel = UpdatePheromoneLevels(pheromoneLevel, deltaPheromoneLevel, rho)
    pheromoneLevel = (1 - rho) * pheromoneLevel + rho * deltaPheromoneLevel;
end