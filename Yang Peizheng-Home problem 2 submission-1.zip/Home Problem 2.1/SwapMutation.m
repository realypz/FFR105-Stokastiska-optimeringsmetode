function swappedChromosome = SwapMutation(chromosome, pMutate)
    swappedChromosome = chromosome;
    
    if rand < pMutate
        chromosomeLength = length(chromosome);
        swapPositions = randperm(chromosomeLength, 2); % return two indices.

    %     disp("swapPositions");
    %     disp(swapPositions);

        cityOne = chromosome(swapPositions(1)); 
        cityTwo = chromosome(swapPositions(2));

        % Swap the two cities
        swappedChromosome(swapPositions(1)) = cityTwo;
        swappedChromosome(swapPositions(2)) = cityOne;
    end
end