clear; close all; clc;

cityLocation = LoadCityLocations;

nCity = size(cityLocation, 1);
citySet = 1:nCity;

%% Compute the distance matrix.
distanceMatrix = zeros(nCity, nCity);
for i = 1:nCity
    for j = 1:nCity
        distanceMatrix(i, j) = norm(cityLocation(i, :) - cityLocation(j, :));
%             distanceMatrix(j, i) = distanceMatrix(i, j);
    end
end

%% Compute the nearest path, and the NN distance together.
path = zeros(1, nCity);
startNode = randperm(nCity, 1);
path(1) = startNode;

nearestNeighbourPathLength = 0;
for i = 2:nCity
    thisCity = path(i-1);
    visitedCitySet = path(1:i-1);
    unvisitedCitySet = setdiff(citySet, visitedCitySet);

    distanceForThisCity = distanceMatrix(thisCity, unvisitedCitySet);

    [nearestDistance, nearestIndex] = min(distanceForThisCity);
    nearestCity = unvisitedCitySet(nearestIndex);
    path(i) = nearestCity;      % Add the found nearest city to path.
    nearestNeighbourPathLength = nearestNeighbourPathLength + nearestDistance;      %Update nearestNeighbourPathLength.
end

nearestNeighbourPath = path; % NNPath
nearestDistance = distanceMatrix(path(nCity), path(1));
nearestNeighbourPathLength = nearestNeighbourPathLength + nearestDistance;      % NN distance
disp(sprintf('NN path is %.2f',nearestNeighbourPathLength));


