function pathLength = GetPathLength(path, cityLocation)
    nCity = length(path);
    pathLength = 0;
    
    for i = 1:(nCity - 1)
        n1 = path(i); % n1, n2 stores the city number.
        n2 = path(i+1);
        distance = ComputeDistance(n1, n2, cityLocation);
        pathLength = pathLength + distance;
    end
    n1 = path(nCity); % n1, n2 stores the city number.
    n2 = path(1);
    pathLength = pathLength + ComputeDistance(n2, n1, cityLocation); % Add the distance between the last and the first.
end