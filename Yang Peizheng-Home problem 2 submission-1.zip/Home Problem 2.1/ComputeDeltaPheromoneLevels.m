function deltaPheromoneLevel = ComputeDeltaPheromoneLevels(pathCollection, pathLengthCollection)
    [nAnt, nCity] = size(pathCollection);
    deltaPheromoneLevel = zeros(nCity, nCity);
    
    for iAnt = 1:nAnt
       deltaTauMatrixThisAnt = zeros(nCity, nCity);
       travelPathThisAnt = pathCollection(iAnt, :);
       travelLenthThisAnt = pathLengthCollection(iAnt);
       
       % 3.1 Determine deltaTau for each ant
       for iCity = 1:nCity-1
           startNode = travelPathThisAnt(iCity);
           endNode = travelPathThisAnt(iCity + 1);
           deltaTauMatrixThisAnt(endNode, startNode) = 1 / travelLenthThisAnt;
       end
       
       % Manually modify deltaTauMatrixThisAnt for edge(last city, first
       % city).
       startNode = travelPathThisAnt(nCity);
       endNode = travelPathThisAnt(1);
       deltaTauMatrixThisAnt(endNode, startNode) = 1 / travelLenthThisAnt;      
       
       
       % Sum deltaTau
       deltaPheromoneLevel = deltaPheromoneLevel + deltaTauMatrixThisAnt;
       
    end
end