function population = InitializePopulation(populationSize, nGenes)
    % nGenes = nCity in TSM problem.
    population = zeros(populationSize, nGenes);
    for i = 1:populationSize
        population(i, :) = [1, 1+randperm(nGenes-1)];
    end
end