function iSelected = RouletteWheelSelection(fitness) % fitness is a vector of length N.
    populationSize = length(fitness);
    accumulatedFitness = zeros(1, populationSize);
    
    temp = 0;
    for i = 1:populationSize
        temp = temp + fitness(i);
        accumulatedFitness(i) = temp;
    end
    

    accumulatedFitness = 1/accumulatedFitness(populationSize) * accumulatedFitness;

    % Select the number of chromosome by Roulette-Wheel selection.
    randNumber = rand;
    
    j = 1;
    for j = 1:populationSize
        if ((accumulatedFitness(j) > randNumber))
            break
        end
    end
    iSelected = j;
end