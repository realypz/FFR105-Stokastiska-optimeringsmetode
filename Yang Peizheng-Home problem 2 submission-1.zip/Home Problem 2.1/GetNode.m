function citySelected = GetNode(startNode, unvisitedNodes, pheromoneLevel, visibilityMatrix, alpha, beta) % fitness is a vector of length N.

    % compute the probability of the current node to each untraversed node.
    temp = (pheromoneLevel(unvisitedNodes, startNode) .^ alpha) .* (visibilityMatrix(unvisitedNodes, startNode) .^ beta);
    denominator = sum(temp);  
    probability = temp / denominator;
    
    fitness = probability;
    populationSize = length(fitness);
    
    accumulatedFitness = zeros(1, populationSize);
    temp = 0;
    for i = 1:populationSize
        temp = temp + fitness(i);
        accumulatedFitness(i) = temp;
    end
    fitnessSum = sum(fitness);
    
    % Normalize accumulatedFitness.
    accumulatedFitness = 1 / fitnessSum * accumulatedFitness;
    
    % Select the number of chromosome by Roulette-Wheel selection.
    randNumber = rand;

    for j = 1:populationSize
        if ((accumulatedFitness(j) > randNumber))
            break
        end
    end

    citySelected = unvisitedNodes(j);

end