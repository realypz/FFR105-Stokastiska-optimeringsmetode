function distance = ComputeDistance(n1, n2, cityLocation)
    % Compute the distance between city n1 and city n2.
    position1 = cityLocation(n1,:);
    position2 = cityLocation(n2,:);
    distance = norm(position1 - position2);
end