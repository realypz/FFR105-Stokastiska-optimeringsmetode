function visibility = GetVisibility(cityLocation)
    nCity = length(cityLocation);
    visibility = zeros(nCity, nCity);
    
    for i = 1:nCity
        for j = 1:nCity
            visibility(i, j) = 1 / ComputeDistance(i, j, cityLocation);
        end
    end
end