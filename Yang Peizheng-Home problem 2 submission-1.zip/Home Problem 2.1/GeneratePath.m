function visitedNodes = GeneratePath(pheromoneLevel, visibilityMatrix, alpha, beta)
    nCity = length(pheromoneLevel);
%     path = zeros(1, nCity);
    visitedNodes = randperm(50,1); % For each ant, randomly initialize the starting node.
    
    citySet = 1:nCity;
    
    for iCity = 2:nCity
            currentNode = visitedNodes(end);
           
            unvisitedNodes = setdiff(citySet, visitedNodes);
            
            % select the next city, and add it to the path.
            citySelected = GetNode(currentNode, unvisitedNodes, pheromoneLevel, visibilityMatrix, alpha, beta);
            
            visitedNodes = [visitedNodes, citySelected];
    end
    
end