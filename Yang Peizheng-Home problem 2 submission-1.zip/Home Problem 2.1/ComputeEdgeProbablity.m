function probability = ComputeEdgeProbablity(startNode, unvisitedNodes, visibilityMatrix, pheromoneLevel, alpha, beta)
% This function computes each p(e_ij|S) = ..., from startNode to aimNode
  % -------- Use see below, the matrix multiplication version of

    temp = (pheromoneLevel(unvisitedNodes, startNode) .^ alpha) .* (visibilityMatrix(unvisitedNodes, startNode) .^ beta);
    denominator = sum(temp);  
    probability = temp / denominator;

end