%% Home Problem 2.1 b
clc; clear; close all;


% Load the locations of the cities.
cityLocation = LoadCityLocations;

range = [0 20 0 20];
tspFigure = InitializeTspPlot(cityLocation, range);
connection = InitializeConnections(cityLocation);

% Define some parameters.
nCities = size(cityLocation, 1);
populationSize = 200;
nGenes = nCities;
nGenerations = 10000;
pMutate = 0.01;
nCopies = 1;

% Initialize population
population = InitializePopulation(populationSize, nGenes);
fitness = zeros(populationSize, 1);
lastbestFitness = 0;

% Encoding the chromosome
for iGeneration = 1:nGenerations
    
    bestFitness = -Inf;
    for i = 1:populationSize
        chromosome = population(i, :);
        fitness(i) = EvaluateIndividual(chromosome, cityLocation);

        % Before mutation, find the best fitness of the tempPopulation, and find the
        % corresponding chromosomeBest.
        if fitness(i) > bestFitness
            bestFitness = fitness(i);
            chromosomeBest = chromosome;
            bestAnt = i;
            
        end
    end
    
    if bestFitness > lastbestFitness
        % Update the plot if find a better chromosome.
        minimumPathLength = GetPathLength(chromosomeBest, cityLocation);
        disp(sprintf('Generation %d, ant %d: path length = %.5f',iGeneration, bestAnt, minimumPathLength));
        PlotPath(connection, cityLocation, chromosomeBest);
        
        lastbestFitness = bestFitness;
    end
    
    % Form the next generation.
    tempPopulation = population;
    
    for i = 1:2:populationSize

        % Select two individuals i1 and i2 from the evaluated population.
        i1 = RouletteWheelSelection(fitness);
        i2 = RouletteWheelSelection(fitness);
        chromosome1 = population(i1, :);
        chromosome2 = population(i2, :);

        % Swap chromosome1 and chromosome2.
        swappedChromosome1 = SwapMutation(chromosome1, pMutate);
        swappedChromosome2 = SwapMutation(chromosome2, pMutate);
        
        tempPopulation(i, :) = swappedChromosome1;
        tempPopulation(i+1, :) = swappedChromosome2;
    end
    
    % Elitism
    modifiedPopulation = InsertBestIndividual(tempPopulation, chromosomeBest, nCopies);
    population = modifiedPopulation; % Update the population of this generation.
end


bestPathLength = GetPathLength(chromosomeBest, cityLocation);
disp(bestPathLength);