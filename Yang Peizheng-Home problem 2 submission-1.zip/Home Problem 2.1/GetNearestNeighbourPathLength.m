function nearestNeighbourPathLength = GetNearestNeighbourPathLength(cityLocation)
    nCity = length(cityLocation);
    citySet = 1:nCity;
    
    nearestNeighbourPathLength = 0;
    
    % Compute the distance matrix.
    distanceMatrix = zeros(nCity, nCity);
    for i = 1:nCity
        for j = 1:nCity
            distanceMatrix(i, j) = norm(cityLocation(i, :) - cityLocation(j, :));
        end
    end
    
    
	path = zeros(1, nCity);
    startNode = randperm(nCity, 1);
    path(1) = startNode;
    
    for i = 2:nCity
        thisCity = path(i-1);
        visitedCitySet = path(1:i-1);
        

        unvisitedCitySet = setdiff(citySet, visitedCitySet);
        
        distanceForThisCity = distanceMatrix(thisCity, unvisitedCitySet);
        
        if i == 50
            disp(i);
        end
        
        [nearestDistance, nearestIndex] = min(distanceForThisCity);
        nearestCity = unvisitedCitySet(nearestIndex);
        path(i) = nearestCity;      % Add the found nearest city to path.
        nearestNeighbourPathLength = nearestNeighbourPathLength + nearestDistance;      %Update nearestNeighbourPathLength.
    end
    
    % Add the distance between the last visited city and the starting city
    nearestDistance = distanceMatrix(path(nCity), path(1));
    nearestNeighbourPathLength = nearestNeighbourPathLength + nearestDistance;      %Update nearestNeighbourPathLength.
end