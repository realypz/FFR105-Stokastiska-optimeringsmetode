function fitness = EvaluateIndividual(chromosome, cityLocation)
    path = chromosome;
    pathLength = GetPathLength(path, cityLocation);
    fitness = 1/pathLength;
end