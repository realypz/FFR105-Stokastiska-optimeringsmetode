function restrictedVelocity = RestrictVelocity(velocity, positionRange, deltaTime)
    nDimension = size(positionRange, 2);
    restrictedVelocity = velocity;
    
    for j = 1:nDimension
        xMax = max(positionRange(j, :));
        xMin = min(positionRange(j, :));
        vMax = (xMax - xMin) / deltaTime;
        if (velocity(j) > vMax)
            restrictedVelocity(j) = vMax;
        end
        
        if (velocity(j) < -vMax)
            restrictedVelocity(j) = -vMax;
        end            
    end
end