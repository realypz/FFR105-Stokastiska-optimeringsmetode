function newVelocity = UpdateVelocity(thisVelocity, deltaTime, inertiaWeight, c1, c2, position, ...
                                        globalBestPosition, bestPositionThisParticle)

    newVelocity = thisVelocity;
    
    nDimension = size(thisVelocity, 2);
    
    for j = 1:nDimension
        q = rand;
        r = rand; 
        newVelocity(j) = inertiaWeight * thisVelocity(j) + c1 * q * (bestPositionThisParticle(j) - position(j)) / deltaTime ...
                                + c2 * r * (globalBestPosition(j) - position(j)) / deltaTime;
    end
end