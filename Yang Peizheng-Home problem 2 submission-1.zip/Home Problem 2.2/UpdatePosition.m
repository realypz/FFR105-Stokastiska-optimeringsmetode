function updatedPosition = UpdatePosition(position, velocity, deltaTime)
    updatedPosition = position + deltaTime * velocity;
end