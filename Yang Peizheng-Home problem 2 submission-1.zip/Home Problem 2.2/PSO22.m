%% main
clear; clc; close all;

%% Plot local minima
nPoints = 1000;
xs = linspace(-5, 5, nPoints);
ys = linspace(-5, 5, nPoints);
[X, Y] = meshgrid(xs, ys);
Z =  log(0.01 + (X.^2 + Y - 11).^2 + (X + Y.^2 - 7).^2 ); %z =  log(0.01 + f(x,y))
contour(X,Y,Z, 50);

%% 
positionRange = [-10, 10;  % dimension 1
                 -10, 10]; % dimension 2 
populationSize = 200;
deltaTime = 1;
inertiaWeight = 1.4;
c1 = 2; % cognitive component
c2 = 2; % social component

%% Step 1: Initialize positions and velocities.
populationVelocities = InitializeVelocities(populationSize, positionRange);
populationPositions = InitializePositions(populationSize, positionRange);


%% Step 2: Evaluate each particle in the swarm.

for iteration = 1:2000
    
    % Display the progress
    if mod(iteration, 200) == 0
        disp(["the "+ num2str(iteration) + "-th iteration"]);
    end

    functionValues = zeros(populationSize, 1);
    for i = 1:populationSize
        thisPosition = populationPositions(i,:);
        functionValues(i) = f(thisPosition);
    end

%% Step 3: Update the best postition of each particle.
    if iteration == 1
        individualBestPositionList = populationPositions; % Initialize the best populations.
        
        [~,idx] = min(functionValues);
        globalBestPosition = populationPositions(idx, :);
    else
        for i = 1:populationSize
            if functionValues(i) < f(individualBestPositionList(i,:))
                individualBestPositionList(i,:) = populationPositions(i,:);
            end
            
            if functionValues(i) < f(globalBestPosition)
                globalBestPosition = populationPositions(i,:);
            end
        end
    end
    
%% Step 4:  Update particle velocities and positions

    inertiaWeight = 0.999 * inertiaWeight; % varying inertia weight
    
    if inertiaWeight <= 0.4 % bound the intertial weight
        inertiaWeight = 0.4;
    end

    % Update velocities
    for i = 1:populationSize
        thisPosition = populationPositions(i,:);
        thisVelocity = populationVelocities(i,:);
        bestPositionThisParticle = individualBestPositionList(i,:);
        populationVelocities(i,:) = UpdateVelocity(thisVelocity, deltaTime, inertiaWeight, c1, c2, thisPosition, ...
                                        globalBestPosition, bestPositionThisParticle);
    end
    
    for i = 1:populationSize
        thisVelocity = populationVelocities(i,:);
        populationVelocities(i,:) = RestrictVelocity(thisVelocity, positionRange, deltaTime);
    end
    
    for i = 1:populationSize
        thisPosition = populationPositions(i,:);
        thisVelocity = populationVelocities(i,:);
        populationPositions(i,:) = UpdatePosition(thisPosition, thisVelocity, deltaTime);
    end
end

%% Plot the points
hold on;

scatter(globalBestPosition(:,1),globalBestPosition(:,2),'MarkerEdgeColor',[0 0 0],...
              'MarkerFaceColor',[0 0 0],...
              'LineWidth',2)
fmin = f(globalBestPosition);