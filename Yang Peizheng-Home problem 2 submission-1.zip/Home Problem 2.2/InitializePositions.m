function populationPositions = InitializePositions(populationSize, positionRange)
    nVariable = size(positionRange, 1);
    populationPositions = zeros(populationSize, nVariable);
    
    for i = 1:populationSize
        for j = 1:nVariable
            xMin = min(positionRange(j, :));
            xMax = max(positionRange(j, :));
            populationPositions(i, j) = xMin + rand * (xMax - xMin);
        end
    end
end