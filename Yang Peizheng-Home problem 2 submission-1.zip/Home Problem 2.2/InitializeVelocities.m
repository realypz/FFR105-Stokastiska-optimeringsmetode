function populationVelocities = InitializeVelocities(populationSize, positionRange)
    nVariable = size(positionRange, 1);
    populationVelocities = zeros(populationSize, nVariable);   
    
    alpha = 1;
    deltaTime = 1;
    for i = 1:populationSize
        for j = 1:nVariable
            xMin = min(positionRange(j, :));
            xMax = max(positionRange(j, :));
            populationVelocities(i, j) = alpha / deltaTime * (- (xMax - xMin)/2 + rand * (xMax - xMin));
        end
    end
end