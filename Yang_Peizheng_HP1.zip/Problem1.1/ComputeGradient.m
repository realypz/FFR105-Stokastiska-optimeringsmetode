function fD = ComputeGradient(x, mu)
    x1 = x(1);
    x2 = x(2);
    if (x1^2 + x2^2 > 1) % g(x) <= 0 does not hold.
        fD1 = 2 * (x1 - 1) + 4 * mu * x1 * (x1^2 + x2^2 - 1);
        fD2 = 4 * (x2 - 2) + 4 * mu * x2 * (x1^2 + x2^2 - 1);
    else
        fD1 = 2 * (x1 - 1);
        fD2 = 4 * (x2 - 2);
    end  
    fD = [fD1, fD2];
end