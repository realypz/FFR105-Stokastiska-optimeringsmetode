function x = RunGradientDescent(xStart, mu, stepLength, threshold)
    x = xStart;
    gradient = ComputeGradient(x, mu);
    gradientNorm = norm(gradient);
    
    while (gradientNorm >= threshold)
        x = x - stepLength * gradient;
        gradient = ComputeGradient(x, mu);
        gradientNorm = norm(gradient);
    end
    
end