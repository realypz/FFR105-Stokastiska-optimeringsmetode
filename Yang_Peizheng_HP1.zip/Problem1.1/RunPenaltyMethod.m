%% RunPenaltyMethod.m
clear; clc; close all;

threshold = 1e-6;
muSet = [1, 10, 100, 1e3, 1e4, 1e5, 1e6];
stepLengthSet = [1e-4, 1e-4, 1e-4, 1e-4, 1e-5, 1e-6, 1e-7];
xStart = [1, 2];

varTypes = {'int32', 'double', 'double'};
varNames = {'mu','x1','x2'};
T = table('Size', [length(muSet), length(varNames)], ...
          'VariableTypes', varTypes, 'VariableNames',varNames); % Initialize a table to store mu, x1*, x2*.

for i = 1:length(muSet)
    stepLength = stepLengthSet(i);
    mu = muSet(i);
    x = RunGradientDescent(xStart, mu, stepLength, threshold);
    
    T.mu(i) = muSet(i);
    T.x1(i) = x(1);     
    T.x2(i) = x(2);
end

disp(T);