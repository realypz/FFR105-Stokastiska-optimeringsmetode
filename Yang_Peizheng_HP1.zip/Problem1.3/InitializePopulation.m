function population = InitializePopulation(populationSize, nGenes)
    numberOfGenes = nGenes;
    population = fix(2.0 * rand(populationSize, numberOfGenes));
end