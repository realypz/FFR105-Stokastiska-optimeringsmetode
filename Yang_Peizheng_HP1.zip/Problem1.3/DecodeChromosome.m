function x = DecodeChromosome(chromosome, nVariables, variableRange)
    nGenes = length(chromosome);    
    variableSize = nGenes/nVariables;   % the number of genes that belong to one variable.
    x = zeros(1, nVariables); 
    
    binarySeries = zeros(1, variableSize); 
    for i = 1:length(binarySeries)
        binarySeries(i) = 0.5^i;    % binarySeries = [1/2, 1/4, 1/8, ..., (1/2)^variableSize]
    end
    
    for j = 1:nVariables
        subChromosome = chromosome(1+(j-1)*variableSize:j*variableSize);
        x(j) = subChromosome * binarySeries.'; % x(j) = [1 0 1 ...]*[1/2, 1/4, 1/8,]'
        x(j) = - variableRange + 2 * variableRange * x(j) / (1 - 2^(-variableSize));
    end
end