%% main script for home problem 1.3
clear; clc; close all;

%% Define some parameters
populationSize = 100; 
nGenes = 50; % Chromosome length
crossoverProbability = 0.8;
tournamentSize = 2;
tournamentSelectionParameter = 0.75;
mutationProbability = 0.02;
nCopies = 1;

nVariables = 2;
variableRange = 10;

nRuns = 100;
nGenerations = 100;


%% Implement the GA
fitness = zeros(populationSize, 1); % Initialize fitness
population = InitializePopulation(populationSize, nGenes);

for iGeneration = 1:nGenerations

    % Evaluate each individual of the population.
    bestFitness = -Inf;
    for i = 1:populationSize
        chromosome = population(i, :);
        x = DecodeChromosome(chromosome, nVariables, variableRange);
        fitness(i) = EvaluateIndividual(x);

        % Before mutation, find the best fitness of the tempPopulation, and find the
        % corresponding chromosomeBest.
        if fitness(i) > bestFitness
            bestFitness = fitness(i);
            chromosomeBest = chromosome;
        end
    end

    %  Keep an exact copy of xBest
    xBest = DecodeChromosome(chromosomeBest, nVariables, variableRange);                    

    % Form the next generation.
    tempPopulation = population;

    for i = 1:2:populationSize

        % Select two individuals i1 and i2 from the evaluated population.
        i1 = TournamentSelect(fitness, tournamentSelectionParameter, tournamentSize);
        i2 = TournamentSelect(fitness, tournamentSelectionParameter, tournamentSize);
        chromosome1 = population(i1, :);
        chromosome2 = population(i2, :);

        % Generate two offspring chromosomes by crossing, with probability pc,
        % the two chromosomes ci1 and ci2 of the two parents. With probability
        % 1-c, copy the parent chromosomes without modification.

        r = rand;
        if (r < crossoverProbability)
            newChromosomePair = Cross(chromosome1, chromosome2);                  
            tempPopulation(i, :) = Mutate(newChromosomePair(1,:), mutationProbability);
            tempPopulation(i+1, :) = Mutate(newChromosomePair(2,:), mutationProbability); 
        else
            tempPopulation(i, :) = Mutate(chromosome1, mutationProbability);
            tempPopulation(i+1, :) = Mutate(chromosome2, mutationProbability);
        end
    end

    % Elitism
    modifiedPopulation = InsertBestIndividual(tempPopulation, chromosomeBest, nCopies);

    population = modifiedPopulation; % Update the population of this generation.
end

% Compute the best fitness of the final generation.
bestFitnessThisRun = bestFitness; % Store the best

disp('The minimum value found in this run is ');
disp(1/bestFitnessThisRun);
disp('The corresponding variable value is');
disp(xBest);